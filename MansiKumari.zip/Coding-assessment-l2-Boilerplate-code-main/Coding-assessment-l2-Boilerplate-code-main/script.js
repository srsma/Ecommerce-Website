async function fetchProducts() {
    try {
        const response = await fetch('https://cdn.shopify.com/s/files/1/0564/3685/0790/files/multiProduct.json');
        const data = await response.json();
        
        console.log(data);  // Log the entire API response to inspect structure

        // Check if men category exists and has products
        if (data.men && data.men.length > 0) {
            displayProducts('men', data.men);
        } else {
            console.error('Men category data is missing or empty');
        }
        if (data.women && data.women.length > 0) {
            displayProducts('women', data.women);
        } else {
            console.error('women category data is missing or empty');
        }
        if (data.kids && data.kids.length > 0) {
            displayProducts('kids', data.kids);
        } else {
            console.error('kids category data is missing or empty');
        }
    } catch (error) {
        console.error('Error fetching product data:', error);
    }
}



function displayProducts(category, products) {
    const categoryContainer = document.getElementById(category);
    categoryContainer.innerHTML = '';  // Clear existing content

    // If products are empty, display a message
    if (products.length === 0) {
        categoryContainer.innerHTML = '<p>No products available for this category.</p>';
        return;
    }

    // Render product cards
    products.forEach(product => {
        const discountPercentage = calculateDiscount(product.price, product.compare_at_price);
        const productCard = `
            <div class="product-card">
                <div class="label">${product.badge}</div>
                <img src="${product.image}" alt="${product.title}">
                <h3>${product.title}</h3>
                <p>${product.vendor}</p>
                <p class="price">Rs ${product.price}.00 <span class="original-price">Rs ${product.compare_at_price}.00</span> <span class="discount">${discountPercentage}% Off</span></p>
                <button class="cart-btn">Add to Cart</button>
            </div>
        `;
        categoryContainer.innerHTML += productCard;
    });
}


// Function to calculate discount percentage
function calculateDiscount(price, compareAtPrice) {
    return Math.round(((compareAtPrice - price) / compareAtPrice) * 100);
}

// Tab switching logic
function showCategory(category) {

    const categories = document.querySelectorAll('.category-content');
    const buttons = document.querySelectorAll('.tab-btn');

    categories.forEach(cat => {
        cat.classList.add('hidden');
    });

    buttons.forEach(btn => {
        btn.classList.remove('active');
    });

    document.getElementById(category).classList.remove('hidden');
    document.querySelector(`button[onclick="showCategory('${category}')"]`).classList.add('active');
}

// Fetch products on page load
document.addEventListener('DOMContentLoaded', () => {
    fetchProducts();
});

